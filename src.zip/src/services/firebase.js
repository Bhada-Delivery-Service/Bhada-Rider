import { initializeApp } from 'firebase/app';
import { getAuth, signInWithCredential, PhoneAuthProvider } from 'firebase/auth';
import { FirebaseAuthentication } from '@capacitor-firebase/authentication';

const firebaseConfig = {
  apiKey: import.meta.env.VITE_FIREBASE_API_KEY,
  authDomain: import.meta.env.VITE_FIREBASE_AUTH_DOMAIN,
  projectId: import.meta.env.VITE_FIREBASE_PROJECT_ID,
  storageBucket: import.meta.env.VITE_FIREBASE_STORAGE_BUCKET,
  messagingSenderId: import.meta.env.VITE_FIREBASE_MESSAGING_SENDER_ID,
  appId: import.meta.env.VITE_FIREBASE_APP_ID,
  measurementId: import.meta.env.VITE_FIREBASE_MEASUREMENT_ID,
};

const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);

let savedVerificationId = null;

export const sendOTP = async (phoneNumber) => {
  try {
    // ✅ Pehle purane listeners remove karo
    await FirebaseAuthentication.removeAllListeners();

    // ✅ Promise banao jo verificationId milne tak wait kare
    const verificationIdPromise = new Promise((resolve, reject) => {
      FirebaseAuthentication.addListener('phoneCodeSent', (event) => {
        console.log('verificationId:', event.verificationId);
        savedVerificationId = event.verificationId;
        resolve(event.verificationId);
      });

      // 30 second timeout
      setTimeout(() => reject(new Error('OTP timeout')), 30000);
    });

    // ✅ OTP request karo
    await FirebaseAuthentication.signInWithPhoneNumber({
      phoneNumber: phoneNumber,
    });

    // ✅ verificationId aane tak wait karo
    await verificationIdPromise;

    console.log('OTP bheja gaya! ID saved:', savedVerificationId);
    return true;

  } catch (error) {
    console.error('OTP Send Error:', error);
    throw error;
  }
};

export const verifyOTP = async (otp) => {
  try {
    if (!savedVerificationId) {
      throw new Error('VerificationId nahi mila — pehle OTP bhejo');
    }

    const result = await FirebaseAuthentication.confirmVerificationCode({
      verificationId: savedVerificationId,
      verificationCode: otp,
    });

    const credential = PhoneAuthProvider.credential(
      savedVerificationId,
      otp
    );

    const userCredential = await signInWithCredential(auth, credential);
    savedVerificationId = null;

    return userCredential.user.getIdToken();

  } catch (error) {
    console.error('OTP Verify Error:', error);
    throw error;
  }
};

export default app;