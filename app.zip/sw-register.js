/**
 * firebase-messaging-sw.js
 * Service worker for Firebase background push notifications.
 *
 * This file MUST be in the /public folder (served at the root URL).
 * Firebase registers it automatically when getToken() is called.
 *
 * This handles push notifications when the app is CLOSED or in the background.
 * When the rider taps the notification, the app opens to the order page.
 */

importScripts('https://www.gstatic.com/firebasejs/10.12.0/firebase-app-compat.js');
importScripts('https://www.gstatic.com/firebasejs/10.12.0/firebase-messaging-compat.js');

// Must match the config in firebase.js exactly
firebase.initializeApp({
  apiKey:            'AIzaSyAe-PAuB9GlFX4YlJoFPrfJ9m-NPTW4Ejs',
  authDomain:        'bhada-api.firebaseapp.com',
  projectId:         'bhada-api',
  storageBucket:     'bhada-api.firebasestorage.app',
  messagingSenderId: '478743960698',
  appId:             '1:478743960698:web:f20eee2387d9aa81e0efc3',
});

const messaging = firebase.messaging();

// Background message handler — fires when app is closed or tab is not focused.
// Firebase shows the notification automatically using notification.title/body.
// The `data` payload is available when rider taps the notification.
messaging.onBackgroundMessage((payload) => {
  console.log('[SW] Background push received:', payload);

  const { title, body } = payload.notification || {
    title: '📦 New Order Available!',
    body:  'A new delivery order is waiting. Tap to view.',
  };

  self.registration.showNotification(title, {
    body,
    icon:    '/icon-192.png',   // add your app icon to /public/icon-192.png
    badge:   '/icon-192.png',
    data:    payload.data,      // orderId etc. available on tap
    tag:     'order-alert',     // replaces previous notification instead of stacking
    renotify: true,
  });
});

// When rider taps the notification, open/focus the app on the correct order page
self.addEventListener('notificationclick', (event) => {
  event.notification.close();

  const data    = event.notification.data || {};
  const orderId = data.orderId;
  const url     = orderId ? `/#/orders/${orderId}` : '/';

  event.waitUntil(
    clients.matchAll({ type: 'window', includeUncontrolled: true }).then((windowClients) => {
      // If the app is already open, focus it and navigate
      for (const client of windowClients) {
        if ('focus' in client) {
          client.focus();
          client.navigate(url);
          return;
        }
      }
      // Otherwise open a new window
      if (clients.openWindow) {
        return clients.openWindow(url);
      }
    })
  );
});