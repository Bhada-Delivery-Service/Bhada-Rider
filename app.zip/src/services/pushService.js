/**
 * pushService.js — FCM push notifications using Firebase Web Messaging.
 *
 * Uses the same Firebase app already configured in firebase.js (phone auth).
 * Works in: browser dev, Android Capacitor webview, and PWA.
 *
 * For background push (app closed/minimized) a service worker handles it —
 * see public/firebase-messaging-sw.js.
 *
 * SETUP (one-time):
 *   1. Firebase Console → Project Settings → Cloud Messaging
 *      → Web Push certificates → Generate key pair
 *   2. Copy the key and add to .env:
 *      VITE_FIREBASE_VAPID_KEY=your_key_here
 */

import { getMessaging, getToken, onMessage } from 'firebase/messaging';
import app from './firebase';
import { ridersAPI } from './api';
import { logger } from '../utils/logger';

const log = logger('Push');

const VAPID_KEY = import.meta.env.VITE_FIREBASE_VAPID_KEY;

let initialized = false;
let messaging   = null;

function getMessagingInstance() {
  if (!messaging) {
    messaging = getMessaging(app);
  }
  return messaging;
}

/**
 * Call once after login.
 * Gets the FCM token and saves it to the backend.
 * Sets up foreground message handler.
 *
 * @param {string}   riderUid   - Logged-in rider's UID
 * @param {function} onNavigate - Called with orderId when rider taps a push
 */
export async function initPushNotifications(riderUid, onNavigate) {
  if (initialized) return;

  try {
    // Request notification permission
    const permission = await Notification.requestPermission();
    if (permission !== 'granted') {
      log.warn('Push permission denied');
      return;
    }

    const msg = getMessagingInstance();

    // Get FCM token — this is always a plain string
    const token = await getToken(msg, {
      vapidKey: VAPID_KEY,
    });

    if (!token || typeof token !== 'string') {
      log.warn('FCM token not received — check VITE_FIREBASE_VAPID_KEY in .env');
      return;
    }

    log.info('FCM token received, saving to backend…');
    await ridersAPI.saveFcmToken(riderUid, token);
    log.info('FCM token saved');

    // Foreground messages — app is open, socket handles ORDER_AVAILABLE already
    // so we only log here to avoid double-alerting
    onMessage(msg, (payload) => {
      log.debug('Foreground push received (socket handles ORDER_AVAILABLE)', {
        type: payload.data?.type,
      });
    });

    initialized = true;
  } catch (err) {
    // Non-fatal — app works fine without push, just log
    log.warn('initPushNotifications failed', { error: err.message });
  }
}

/**
 * Call on logout — removes token from backend so pushes stop.
 */
export async function clearPushToken(riderUid) {
  try {
    await ridersAPI.clearFcmToken(riderUid);
    initialized = false;
    log.info('FCM token cleared');
  } catch (err) {
    log.warn('Failed to clear FCM token', { error: err.message });
  }
}